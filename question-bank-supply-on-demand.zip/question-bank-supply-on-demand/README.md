# Question Bank - Supply on Demand 🎓

A Flask-based system to dynamically generate question papers based on subject, topic, and course outcomes (COs).

## Features
- Select Subject, Topic, and COs
- Auto-generate a question paper
- Two-page PDF:
  - Page 1: Subject info, Name, Course Outcomes
  - Page 2: Randomly selected questions from the bank

## 🛠 Setup

```bash
git clone https://github.com/yourusername/question-bank-supply-on-demand.git
cd question-bank-supply-on-demand
pip install -r requirements.txt
python app.py
```

## 🔄 Sample API Request

**POST** `/generate_qp`

```json
{
  "name": "John Doe",
  "subject": "subject1",
  "topic": "T1",
  "cos": ["CO1", "CO2"]
}
```

The API will return a downloadable PDF question paper.

## 📌 Notes

- Extend the `database` dictionary in `app.py` for more subjects/questions.
- You can hook a frontend later using HTML + JS or React for UI.
