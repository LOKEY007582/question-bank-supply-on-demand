from flask import Flask, request, jsonify, send_file
import random
import os
from fpdf import FPDF

app = Flask(__name__)

# Sample data structure (in practice, use a database)
database = {
    "subject1": {
        "T1": {
            "CO1": ["Explain the concept of X.", "Describe the process of Y."],
            "CO2": ["Discuss the advantages of Z.", "Illustrate with example A."]
        }
    },
    "subject2": {
        "T1": {
            "CO1": ["What is B?", "Explain C with example."]
        }
    }
}

class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Question Paper", ln=True, align='C')
        self.ln(10)

    def chapter_title(self, title):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, title, ln=True)
        self.ln(5)

    def chapter_body(self, body):
        self.set_font("Arial", "", 12)
        self.multi_cell(0, 10, body)
        self.ln()

@app.route('/get_questions', methods=['POST'])
def get_questions():
    data = request.json
    subject = data.get("subject")
    topic = data.get("topic")
    co = data.get("co")

    questions = database.get(subject, {}).get(topic, {}).get(co, [])
    return jsonify({"questions": questions})

@app.route('/generate_qp', methods=['POST'])
def generate_qp():
    data = request.json
    student_name = data.get("name")
    subject = data.get("subject")
    topic = data.get("topic")
    co_list = data.get("cos", [])

    questions = []
    for co in co_list:
        co_questions = database.get(subject, {}).get(topic, {}).get(co, [])
        if co_questions:
            questions.append(random.choice(co_questions))

    # Generate PDF
    pdf = PDF()
    pdf.add_page()

    # Page 1: Info
    pdf.chapter_title("Student Information")
    pdf.chapter_body(f"Name: {student_name}\nSubject: {subject}\nTopic: {topic}\nCourse Outcomes: {', '.join(co_list)}")

    # Page 2: Questions
    pdf.add_page()
    pdf.chapter_title("Question Paper")
    for i, q in enumerate(questions):
        pdf.chapter_body(f"Q{i+1}: {q}")

    filename = f"question_paper_{subject}.pdf"
    filepath = os.path.join("./", filename)
    pdf.output(filepath)

    return send_file(filepath, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
